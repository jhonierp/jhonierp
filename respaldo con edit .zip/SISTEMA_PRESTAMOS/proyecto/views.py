from ast import GeneratorExp
from django.shortcuts import get_object_or_404, render, redirect
from django.contrib import messages
from django.contrib.auth import authenticate, login
from django.contrib.auth.decorators import login_required
from datetime import date


from proyecto.models import (BeneficiariosPersonasNaturales, Discapacidades, PersonasBeneficiarios, PersonasNaturales,  Ocupaciones,TiposGeneros,
 Paises,TiposDocumentos, Departamentos, Municipios,
 Estudios,TiposViviendas,Parentescos,Porcentajes,  EstadosCiviles,Grupos,PersonasAdministrativas)

# Create your views here.





@login_required
def fun_ahor(request):
    return render(request,"Tablas/ahorros.html")
@login_required
def fun_credi(request):
    return render(request,"Tablas/creditos.html")

@login_required
def fun_tab_main(request):
    fecha_seleccionada = request.GET.get('fecha_sel') 
    partes_fecha = fecha_seleccionada.split('-')
    mesYAnioSeleccionado = f"{partes_fecha[1]}/{partes_fecha[0]}" if len(partes_fecha) == 2 else ""

    grupo_select = request.GET.get('grupo_sel')

    person_fin = PersonasNaturales.objects.filter(fecha_regis=mesYAnioSeleccionado, grupo_id=grupo_select)
    return render(request, "Tablas/tabla_main.html",{'mesYAnioSeleccionado': mesYAnioSeleccionado,'person_fin':person_fin,'grupo_id2':grupo_select})

@login_required
def fun_tab_edit(request):
    return render(request,"Editar/tabla_edit.html")
@login_required
def fun_fil_edit(request):
    return render(request,"Editar/filtro_edit.html")
@login_required


def fun_re_adm(request):
    grupos = Grupos.objects.all()
    generos = TiposGeneros.objects.all()
    ocupaciones = Ocupaciones.objects.all()
    paises = Paises.objects.all()
    documentos = TiposDocumentos.objects.all()
    departamentos = Departamentos.objects.all()
    ciudades = Municipios.objects.all()
    estudios = Estudios.objects.all()
    viviendas = TiposViviendas.objects.all()
    discapacidades = Discapacidades.objects.all()
    parentescos = Parentescos.objects.all()
    porcentajes = Porcentajes.objects.all()
    estadosc = EstadosCiviles.objects.all()
    
    if request.method == 'POST':
        # Obtener los datos del formulario
        nombres = request.POST['nombre_completo']
        apellidos = request.POST['apellidos']
        genero_id = request.POST['genero']
        tipo_doc_id = request.POST['tipo_documento']
        fecha_nacimiento = request.POST['fecha_nacimiento']
        fecha_expedicion = request.POST['fecha_expedicion']
        lugar_expedicion_id = request.POST['ciudad_expedicion']
        num_documento = request.POST['numero_documento']
        discapacidad_id = request.POST['discapacidad']
        correo_electronico = request.POST['email_personal']
        celular1 = request.POST['celular_1']
        celular2 = request.POST['celular_2']
        grupo_id = request.POST['grupo']
        jefe_id = '1'

        # Crear una nueva instancia de PersonasAdministrativas
        administrador = PersonasAdministrativas(
            nombres=nombres,
            apellidos=apellidos,
            genero_id=genero_id,
            tipo_doc_id=tipo_doc_id,
            fecha_nacimiento=fecha_nacimiento,
            fecha_expedicion=fecha_expedicion,
            lugar_expedicion_id=lugar_expedicion_id,
            num_documento=num_documento,
            discapacidad_id=discapacidad_id,
            correo_electronico=correo_electronico,
            celular1=celular1,
            celular2=celular2,
            jefe_id=jefe_id,
        )
        administrador.save()

        # Comprobar si se eligió crear un nuevo grupo
        if grupo_id == 'nuevo':
            nuevo_grupo_nombre = request.POST['nuevo_grupo']
            if nuevo_grupo_nombre:
                # El usuario eligió crear un nuevo grupo y proporcionó un nombre
                nuevo_grupo = Grupos(nombre=nuevo_grupo_nombre, persona_admin=administrador)
                nuevo_grupo.save()
        else:
            # El usuario eligió un grupo existente (o no proporcionó un nombre para uno nuevo)
            grupo = Grupos.objects.get(pk=grupo_id)
            grupo.persona_admin = administrador
            grupo.save()

        return redirect(fun_hom)

    # Si no es una solicitud POST, renderiza el formulario vacío
    return render(request, 'Registros/registro_admin.html', {'generos': generos,
                                                            'ocupaciones': ocupaciones, 'paises': paises,
                                                            'documentos': documentos,
                                                            'departamentos': departamentos, 'ciudades': ciudades,
                                                            'estudios': estudios, 'viviendas': viviendas,
                                                            'discapacidades': discapacidades,
                                                            'parentescos': parentescos, 'porcentajes': porcentajes,
                                                            'estadosc': estadosc, 'grupos': grupos})

@login_required
def fun_hom(request):
    grupos = Grupos.objects.all()
    
    return render(request,"home.html",{'grupos':grupos})
@login_required
def fun_re_us(request):
    generos = TiposGeneros.objects.all()
    ocupaciones = Ocupaciones.objects.all()
    paises = Paises.objects.all()
    documentos = TiposDocumentos.objects.all()
    departamentos = Departamentos.objects.all()
    ciudades = Municipios.objects.all()
    estudios = Estudios.objects.all()
    viviendas = TiposViviendas.objects.all()
    discapacidades = Discapacidades.objects.all()
    parentescos = Parentescos.objects.all()
    porcentajes = Porcentajes.objects.all()
    estadosc = EstadosCiviles.objects.all()
    grupos = Grupos.objects.all()
    
    if request.method == 'POST':
        fecha_actual = date.today()
        pase = fecha_actual.strftime("%m/%Y")
        mes_y_anio_actual = str(pase)

        # Obtener datos del formulario
        nombre_1 = request.POST['nombre_1']
        nombre_2 = request.POST['nombre_2']
        apellido_1 = request.POST['apellido_1']
        apellido_2 = request.POST['apellido_2']
        genero_id = request.POST['genero']
        tipo_documento_id = request.POST['tipo_documento']
        num_documento = request.POST['numero_documento']
        fecha_expedicion = request.POST['fecha_expedicion']
        lugar_expedicion_id = request.POST['ciudad_expedicion']  # Asegúrate de obtener la ciudad correcta
        estado_civil_id = request.POST['estado_civil']
        ocupacion_id = request.POST['ocupacion']
        fecha_nacimiento = request.POST['fecha_nacimiento']
        lugar_nacimiento_id = request.POST['ciudad_nacimiento']  # Asegúrate de obtener la ciudad correcta
        nomenclatura = request.POST['nomenclatura']
        barrio_vereda = request.POST['barrio_vereda']
        pais_id = request.POST['pais_direccion']
        vive_direccion_id = request.POST['ciudad_direccion']  # Asegúrate de obtener la ciudad correcta
        estudios_id = request.POST.get('estudios', None)
        correo_electronico = request.POST['correo_electronico']
        telefono_fijo = request.POST.get('telefono_fijo')
        if telefono_fijo == '':
            telefono_fijo = '0'
        celular1 = request.POST['celular1']
        celular2 = request.POST.get('celular2', None)
        tipo_vivienda_id = request.POST['tipo_vivienda']
        deporte_favorito = request.POST.get('deporte_favorito', None)
        edad = request.POST.get('edad', None)
        discapacidad_id = request.POST['discapacidad']
        nombre_completo_recom = request.POST.get('nombre_integrante', None)
        direccion_recom = request.POST.get('direccion_integrante', None)
        celular_recom = request.POST.get('telefono_integrante', None)
        nombre_completo_familiar = request.POST.get('nombre_referencia', None)
        direccion_familiar = request.POST.get('direccion_referencia', None)
        celular_familiar = request.POST.get('telefono_referencia', None)
        # Asegúrate de obtener el valor correcto
        grupo_id = request.POST['grupo']  # Asegúrate de obtener el valor correcto
        
        # Crear una lista para almacenar los beneficiarios
        beneficiarios = []

        # Procesar los datos de los beneficiarios
        for i in range(1, 5):  # Itera sobre los números del 1 al 4
            nombre_beneficiario = request.POST.get('nombre_beneficiario_' + str(i))
            porcentaje_beneficiario_id = request.POST.get('porcentaje_beneficiario_' + str(i))
            parentesco_beneficiario_id = request.POST.get('parentesco_beneficiario_' + str(i))

            # Verificar si se proporcionó información para el beneficiario
            if nombre_beneficiario and porcentaje_beneficiario_id and parentesco_beneficiario_id:
                # Crear el beneficiario con la clave foránea porcentaje_id
                beneficiario = BeneficiariosPersonasNaturales(
                    nombre_completo=nombre_beneficiario,
                    porcentaje_id=porcentaje_beneficiario_id,
                    parentesco_id=parentesco_beneficiario_id
                )
                beneficiario.save()

                # Agregar el beneficiario a la lista
                beneficiarios.append(beneficiario)

        # Guardar la persona natural
        usuario = PersonasNaturales(
            # ... Código para guardar la persona natural ...
            nombre_1=nombre_1,
            nombre_2=nombre_2,
            apellido_1=apellido_1,
            apellido_2=apellido_2,
            genero_id=genero_id,
            tipo_doc_id=tipo_documento_id,
            num_documento=num_documento,
            fecha_expedicion=fecha_expedicion,
            lugar_expedicion_id=lugar_expedicion_id,
            estado_civil_id=estado_civil_id,
            ocupacion_id=ocupacion_id,
            fecha_nacimiento=fecha_nacimiento,
            lugar_nacimiento_id=lugar_nacimiento_id,
            nomenclatura=nomenclatura,
            barrio_vereda=barrio_vereda,
            pais_id=pais_id,
            vive_direccion_id=vive_direccion_id,
            estudios_id=estudios_id,
            correo_electronico=correo_electronico,
            telefono_fijo=telefono_fijo,
            celular1=celular1,
            celular2=celular2,
            tipo_vivienda_id=tipo_vivienda_id,
            deporte_favorito=deporte_favorito,
            edad=edad,
            discapacidad_id=discapacidad_id,
            nombre_completo_recom=nombre_completo_recom,
            direccion_recom=direccion_recom,
            celular_recom=celular_recom,
            nombre_completo_familiar=nombre_completo_familiar,
            direccion_familiar=direccion_familiar,
            celular_familiar=celular_familiar,
            grupo_id=grupo_id,
            fecha_regis=mes_y_anio_actual
        )
        usuario.save()
        
        # Asociar los beneficiarios con la persona natural
        for beneficiario in beneficiarios:
            persona_beneficiario = PersonasBeneficiarios(
                persona_natural=usuario,
                beneficiario=beneficiario
            )
            persona_beneficiario.save()

        messages.success(request, 'Usuario y beneficiarios registrados exitosamente.')
        return redirect(fun_hom)  # Reemplaza 'pagina_de_exito' con la URL de tu elección

    return render(request,"Registros/registro_user.html",{'generos':generos,
    'ocupaciones':ocupaciones,'paises':paises,'documentos':documentos,
    'departamentos':departamentos,'ciudades':ciudades,
    'estudios':estudios,'viviendas':viviendas,'discapacidades':discapacidades,
    'parentescos':parentescos,'porcentajes':porcentajes,'estadosc':estadosc,'grupos':grupos})

 # Asegúrate de importar el modelo correcto


def fun_reg_edit(request, usuario_id):
    # Obtener el usuario que se va a editar
    usuario = get_object_or_404(PersonasNaturales, pk=usuario_id)
    generos = TiposGeneros.objects.all()
    ocupaciones = Ocupaciones.objects.all()
    paises = Paises.objects.all()
    documentos = TiposDocumentos.objects.all()
    departamentos = Departamentos.objects.all()
    ciudades = Municipios.objects.all()
    estudios = Estudios.objects.all()
    viviendas = TiposViviendas.objects.all()
    discapacidades = Discapacidades.objects.all()
    parentescos = Parentescos.objects.all()
    porcentajes = Porcentajes.objects.all()
    estadosc = EstadosCiviles.objects.all()
    grupos = Grupos.objects.all()

    if request.method == 'POST':
        # Procesar los datos editados y guardarlos en el modelo
        usuario.nombre_1 = request.POST['nombre_1']
        usuario.nombre_2 = request.POST['nombre_2']
        usuario.apellido_1 = request.POST['apellido_1']
        usuario.apellido_2 = request.POST['apellido_2']
        usuario.fecha_expedicion = request.POST['fecha_expedicion']
        usuario.nombre_completo_recom = request.POST['nombre_integrante']
        usuario.direccion_recom = request.POST['direccion_integrante']
        usuario.save()

        # Redirigir a una página de éxito o a donde desees
        # Por ejemplo, a una página de detalles del usuario
        return redirect('detalle_usuario', usuario_id=usuario.id)

    return render(request, 'Editar/registro_edit.html', {'usuario': usuario,'generos':generos,
    'ocupaciones':ocupaciones,'paises':paises,'documentos':documentos,
    'departamentos':departamentos,'ciudades':ciudades,
    'estudios':estudios,'viviendas':viviendas,'discapacidades':discapacidades,
    'parentescos':parentescos,'porcentajes':porcentajes,'estadosc':estadosc,'grupos':grupos})
