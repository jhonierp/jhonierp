from django.contrib import admin
from django.urls import path
from proyecto import views 

urlpatterns = [
    path('', views.fun_hom, name='home'),
    path('ahorros', views.fun_ahor),
    path('creditos', views.fun_credi),
    path('registro_user', views.fun_re_us),
    path('registro_admin', views.fun_re_adm),
    path('tabla_main', views.fun_tab_main),
    path('filtro_edit', views.fun_fil_edit),
    path('editar/<int:usuario_id>/', views.fun_reg_edit, name='fun_reg_edit'),
    path('tabla_edit', views.fun_tab_edit)
]
