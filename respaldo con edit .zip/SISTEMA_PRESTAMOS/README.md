# SISTEMA_PRESTAMOS
repositorio hecho con entusiasmo y actitud para lograr alcanzar los objetivos de practica empresarial
____________________________________________________________________
GUIA:





-base de datos exportarla en mysql (server data import) e importarla como archivo, no como carpeta
-las views y los models, afectan la la pagina
_______________________ settings de sistema ________________________
DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.mysql',
        'NAME': 'p_compumaster',
        'USER': 'root',                 # Puedes cambiar esto según tu configuración
        'PASSWORD': '111221',           # Puedes cambiar esto según tu configuración
        'HOST': 'localhost',            # Puedes cambiar esto según tu configuración
        'PORT': '3306',                 # Puedes cambiar esto según tu configuración
    }
}
