CREATE DATABASE  IF NOT EXISTS `bd_compumaster` /*!40100 DEFAULT CHARACTER SET utf8mb3 */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `bd_compumaster`;
-- MySQL dump 10.13  Distrib 8.0.32, for Win64 (x86_64)
--
-- Host: localhost    Database: bd_compumaster
-- ------------------------------------------------------
-- Server version	8.0.30

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `ahorros`
--

DROP TABLE IF EXISTS `ahorros`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ahorros` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `num_recibo` int DEFAULT NULL,
  `aportes_anteriores` int DEFAULT NULL,
  `aportes_pendientes` int DEFAULT NULL,
  `aportes_por_pagar` int DEFAULT NULL,
  `aportes_recibidos` int DEFAULT NULL,
  `saldo_aportes_por_pagar` int DEFAULT NULL,
  `retiro_de_aportes` int DEFAULT NULL,
  `total_de_aportes` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ahorros`
--

LOCK TABLES `ahorros` WRITE;
/*!40000 ALTER TABLE `ahorros` DISABLE KEYS */;
INSERT INTO `ahorros` VALUES (1,123,1000,2000,3000,4000,5000,1000,5000),(2,124,800,1500,2000,3000,1000,500,3000);
/*!40000 ALTER TABLE `ahorros` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_group`
--

DROP TABLE IF EXISTS `auth_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `auth_group` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(150) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_group`
--

LOCK TABLES `auth_group` WRITE;
/*!40000 ALTER TABLE `auth_group` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_group` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_group_permissions`
--

DROP TABLE IF EXISTS `auth_group_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `auth_group_permissions` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `group_id` int NOT NULL,
  `permission_id` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_group_permissions_group_id_permission_id_0cd325b0_uniq` (`group_id`,`permission_id`),
  KEY `auth_group_permissio_permission_id_84c5c92e_fk_auth_perm` (`permission_id`),
  CONSTRAINT `auth_group_permissio_permission_id_84c5c92e_fk_auth_perm` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`),
  CONSTRAINT `auth_group_permissions_group_id_b120cbf9_fk_auth_group_id` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_group_permissions`
--

LOCK TABLES `auth_group_permissions` WRITE;
/*!40000 ALTER TABLE `auth_group_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_group_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_permission`
--

DROP TABLE IF EXISTS `auth_permission`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `auth_permission` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `content_type_id` int NOT NULL,
  `codename` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_permission_content_type_id_codename_01ab375a_uniq` (`content_type_id`,`codename`),
  CONSTRAINT `auth_permission_content_type_id_2f476e4b_fk_django_co` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=109 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_permission`
--

LOCK TABLES `auth_permission` WRITE;
/*!40000 ALTER TABLE `auth_permission` DISABLE KEYS */;
INSERT INTO `auth_permission` VALUES (1,'Can add log entry',1,'add_logentry'),(2,'Can change log entry',1,'change_logentry'),(3,'Can delete log entry',1,'delete_logentry'),(4,'Can view log entry',1,'view_logentry'),(5,'Can add permission',2,'add_permission'),(6,'Can change permission',2,'change_permission'),(7,'Can delete permission',2,'delete_permission'),(8,'Can view permission',2,'view_permission'),(9,'Can add group',3,'add_group'),(10,'Can change group',3,'change_group'),(11,'Can delete group',3,'delete_group'),(12,'Can view group',3,'view_group'),(13,'Can add user',4,'add_user'),(14,'Can change user',4,'change_user'),(15,'Can delete user',4,'delete_user'),(16,'Can view user',4,'view_user'),(17,'Can add content type',5,'add_contenttype'),(18,'Can change content type',5,'change_contenttype'),(19,'Can delete content type',5,'delete_contenttype'),(20,'Can view content type',5,'view_contenttype'),(21,'Can add session',6,'add_session'),(22,'Can change session',6,'change_session'),(23,'Can delete session',6,'delete_session'),(24,'Can view session',6,'view_session'),(25,'Can add ahorros',7,'add_ahorros'),(26,'Can change ahorros',7,'change_ahorros'),(27,'Can delete ahorros',7,'delete_ahorros'),(28,'Can view ahorros',7,'view_ahorros'),(29,'Can add beneficiarios personas naturales',8,'add_beneficiariospersonasnaturales'),(30,'Can change beneficiarios personas naturales',8,'change_beneficiariospersonasnaturales'),(31,'Can delete beneficiarios personas naturales',8,'delete_beneficiariospersonasnaturales'),(32,'Can view beneficiarios personas naturales',8,'view_beneficiariospersonasnaturales'),(33,'Can add creditos',9,'add_creditos'),(34,'Can change creditos',9,'change_creditos'),(35,'Can delete creditos',9,'delete_creditos'),(36,'Can view creditos',9,'view_creditos'),(37,'Can add departamentos',10,'add_departamentos'),(38,'Can change departamentos',10,'change_departamentos'),(39,'Can delete departamentos',10,'delete_departamentos'),(40,'Can view departamentos',10,'view_departamentos'),(41,'Can add discapacidades',11,'add_discapacidades'),(42,'Can change discapacidades',11,'change_discapacidades'),(43,'Can delete discapacidades',11,'delete_discapacidades'),(44,'Can view discapacidades',11,'view_discapacidades'),(45,'Can add estados civiles',12,'add_estadosciviles'),(46,'Can change estados civiles',12,'change_estadosciviles'),(47,'Can delete estados civiles',12,'delete_estadosciviles'),(48,'Can view estados civiles',12,'view_estadosciviles'),(49,'Can add estudios',13,'add_estudios'),(50,'Can change estudios',13,'change_estudios'),(51,'Can delete estudios',13,'delete_estudios'),(52,'Can view estudios',13,'view_estudios'),(53,'Can add grupos',14,'add_grupos'),(54,'Can change grupos',14,'change_grupos'),(55,'Can delete grupos',14,'delete_grupos'),(56,'Can view grupos',14,'view_grupos'),(57,'Can add municipios',15,'add_municipios'),(58,'Can change municipios',15,'change_municipios'),(59,'Can delete municipios',15,'delete_municipios'),(60,'Can view municipios',15,'view_municipios'),(61,'Can add ocupaciones',16,'add_ocupaciones'),(62,'Can change ocupaciones',16,'change_ocupaciones'),(63,'Can delete ocupaciones',16,'delete_ocupaciones'),(64,'Can view ocupaciones',16,'view_ocupaciones'),(65,'Can add paises',17,'add_paises'),(66,'Can change paises',17,'change_paises'),(67,'Can delete paises',17,'delete_paises'),(68,'Can view paises',17,'view_paises'),(69,'Can add parentescos',18,'add_parentescos'),(70,'Can change parentescos',18,'change_parentescos'),(71,'Can delete parentescos',18,'delete_parentescos'),(72,'Can view parentescos',18,'view_parentescos'),(73,'Can add porcentajes',19,'add_porcentajes'),(74,'Can change porcentajes',19,'change_porcentajes'),(75,'Can delete porcentajes',19,'delete_porcentajes'),(76,'Can view porcentajes',19,'view_porcentajes'),(77,'Can add tipos documentos',20,'add_tiposdocumentos'),(78,'Can change tipos documentos',20,'change_tiposdocumentos'),(79,'Can delete tipos documentos',20,'delete_tiposdocumentos'),(80,'Can view tipos documentos',20,'view_tiposdocumentos'),(81,'Can add tipos generos',21,'add_tiposgeneros'),(82,'Can change tipos generos',21,'change_tiposgeneros'),(83,'Can delete tipos generos',21,'delete_tiposgeneros'),(84,'Can view tipos generos',21,'view_tiposgeneros'),(85,'Can add tipos viviendas',22,'add_tiposviviendas'),(86,'Can change tipos viviendas',22,'change_tiposviviendas'),(87,'Can delete tipos viviendas',22,'delete_tiposviviendas'),(88,'Can view tipos viviendas',22,'view_tiposviviendas'),(89,'Can add personas naturales',23,'add_personasnaturales'),(90,'Can change personas naturales',23,'change_personasnaturales'),(91,'Can delete personas naturales',23,'delete_personasnaturales'),(92,'Can view personas naturales',23,'view_personasnaturales'),(93,'Can add personas jefe',24,'add_personasjefe'),(94,'Can change personas jefe',24,'change_personasjefe'),(95,'Can delete personas jefe',24,'delete_personasjefe'),(96,'Can view personas jefe',24,'view_personasjefe'),(97,'Can add personas beneficiarios',25,'add_personasbeneficiarios'),(98,'Can change personas beneficiarios',25,'change_personasbeneficiarios'),(99,'Can delete personas beneficiarios',25,'delete_personasbeneficiarios'),(100,'Can view personas beneficiarios',25,'view_personasbeneficiarios'),(101,'Can add personas ahorros creditos',26,'add_personasahorroscreditos'),(102,'Can change personas ahorros creditos',26,'change_personasahorroscreditos'),(103,'Can delete personas ahorros creditos',26,'delete_personasahorroscreditos'),(104,'Can view personas ahorros creditos',26,'view_personasahorroscreditos'),(105,'Can add personas administrativas',27,'add_personasadministrativas'),(106,'Can change personas administrativas',27,'change_personasadministrativas'),(107,'Can delete personas administrativas',27,'delete_personasadministrativas'),(108,'Can view personas administrativas',27,'view_personasadministrativas');
/*!40000 ALTER TABLE `auth_permission` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_user`
--

DROP TABLE IF EXISTS `auth_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `auth_user` (
  `id` int NOT NULL AUTO_INCREMENT,
  `password` varchar(128) NOT NULL,
  `last_login` datetime(6) DEFAULT NULL,
  `is_superuser` tinyint(1) NOT NULL,
  `username` varchar(150) NOT NULL,
  `first_name` varchar(150) NOT NULL,
  `last_name` varchar(150) NOT NULL,
  `email` varchar(254) NOT NULL,
  `is_staff` tinyint(1) NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `date_joined` datetime(6) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_user`
--

LOCK TABLES `auth_user` WRITE;
/*!40000 ALTER TABLE `auth_user` DISABLE KEYS */;
INSERT INTO `auth_user` VALUES (1,'pbkdf2_sha256$600000$8eHe5jS7mrBZAy0EhDaIzb$edhDgkQj3V4NjnaKvkXwS+1aggiCjZb2EGUaiaSij40=','2023-10-10 17:46:12.627046',1,'jhonier','','','jhoni@gmail.com',1,1,'2023-10-09 20:55:46.181019');
/*!40000 ALTER TABLE `auth_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_user_groups`
--

DROP TABLE IF EXISTS `auth_user_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `auth_user_groups` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `group_id` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_user_groups_user_id_group_id_94350c0c_uniq` (`user_id`,`group_id`),
  KEY `auth_user_groups_group_id_97559544_fk_auth_group_id` (`group_id`),
  CONSTRAINT `auth_user_groups_group_id_97559544_fk_auth_group_id` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`),
  CONSTRAINT `auth_user_groups_user_id_6a12ed8b_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_user_groups`
--

LOCK TABLES `auth_user_groups` WRITE;
/*!40000 ALTER TABLE `auth_user_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_user_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_user_user_permissions`
--

DROP TABLE IF EXISTS `auth_user_user_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `auth_user_user_permissions` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `permission_id` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_user_user_permissions_user_id_permission_id_14a6b632_uniq` (`user_id`,`permission_id`),
  KEY `auth_user_user_permi_permission_id_1fbb5f2c_fk_auth_perm` (`permission_id`),
  CONSTRAINT `auth_user_user_permi_permission_id_1fbb5f2c_fk_auth_perm` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`),
  CONSTRAINT `auth_user_user_permissions_user_id_a95ead1b_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_user_user_permissions`
--

LOCK TABLES `auth_user_user_permissions` WRITE;
/*!40000 ALTER TABLE `auth_user_user_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_user_user_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `beneficiarios_personas_naturales`
--

DROP TABLE IF EXISTS `beneficiarios_personas_naturales`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `beneficiarios_personas_naturales` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `nombre_completo` varchar(100) NOT NULL,
  `parentesco_id` bigint NOT NULL,
  `porcentaje_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  KEY `beneficiarios_person_parentesco_id_5bccd4ef_fk_parentesc` (`parentesco_id`),
  KEY `beneficiarios_person_porcentaje_id_28f44ac3_fk_porcentaj` (`porcentaje_id`),
  CONSTRAINT `beneficiarios_person_parentesco_id_5bccd4ef_fk_parentesc` FOREIGN KEY (`parentesco_id`) REFERENCES `parentescos` (`id`),
  CONSTRAINT `beneficiarios_person_porcentaje_id_28f44ac3_fk_porcentaj` FOREIGN KEY (`porcentaje_id`) REFERENCES `porcentajes` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=35 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `beneficiarios_personas_naturales`
--

LOCK TABLES `beneficiarios_personas_naturales` WRITE;
/*!40000 ALTER TABLE `beneficiarios_personas_naturales` DISABLE KEYS */;
INSERT INTO `beneficiarios_personas_naturales` VALUES (1,'Juan Perez',3,1),(2,'María López',2,2),(3,'peponcio',2,2),(4,'ruperto',1,2),(5,'pipipi',3,4),(19,'pop',2,2),(20,'phonk',1,2),(21,'funk',3,1),(22,'rockstar',4,3),(23,'sierra',1,1),(24,'roque',2,1),(25,'eqdim',3,3),(26,'marcela',2,3),(27,'lorena',1,1),(28,'carlos',1,1),(29,'jaunchi',1,2),(30,'ssss',3,4),(31,'erere',2,2),(32,'errr',2,1),(33,'firu',2,1),(34,'ttttt',1,2);
/*!40000 ALTER TABLE `beneficiarios_personas_naturales` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `creditos`
--

DROP TABLE IF EXISTS `creditos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `creditos` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `solicitud_de_credito` int DEFAULT NULL,
  `fecha_inicio` date DEFAULT NULL,
  `fecha_final` date DEFAULT NULL,
  `valor_credito_solicitado` int DEFAULT NULL,
  `numero_dias_credito` int DEFAULT NULL,
  `plazo_meses` int DEFAULT NULL,
  `cuota_credito` int DEFAULT NULL,
  `valor_cuota_total` int DEFAULT NULL,
  `credito_actual` int DEFAULT NULL,
  `total_recibido` int DEFAULT NULL,
  `abono_credito` int DEFAULT NULL,
  `saldo_credito` int DEFAULT NULL,
  `interes_credito` int DEFAULT NULL,
  `interes_anterior` int DEFAULT NULL,
  `total_interes_a_pagar` int DEFAULT NULL,
  `intereses_recibidos` int DEFAULT NULL,
  `saldo_intereses` int DEFAULT NULL,
  `nueva_afiliacion` longtext,
  `nota` longtext,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `creditos`
--

LOCK TABLES `creditos` WRITE;
/*!40000 ALTER TABLE `creditos` DISABLE KEYS */;
INSERT INTO `creditos` VALUES (1,1,'2022-04-04','2022-05-05',5000,30,1,1500,1500,5000,1500,0,3500,200,0,200,0,0,'Nueva afiliación','Nota 1'),(2,2,'2022-04-05','2022-05-06',3000,30,1,1000,1000,3000,1000,0,2000,150,0,150,0,0,'Nueva afiliación','Nota 2');
/*!40000 ALTER TABLE `creditos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `departamentos`
--

DROP TABLE IF EXISTS `departamentos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `departamentos` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `nombre` varchar(45) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `departamentos`
--

LOCK TABLES `departamentos` WRITE;
/*!40000 ALTER TABLE `departamentos` DISABLE KEYS */;
INSERT INTO `departamentos` VALUES (1,'Antioquia'),(2,'Atlántico'),(3,'Bogotá, D.C.'),(4,'Bolívar'),(5,'Boyacá');
/*!40000 ALTER TABLE `departamentos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `discapacidades`
--

DROP TABLE IF EXISTS `discapacidades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `discapacidades` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `descripcion` varchar(45) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `discapacidades`
--

LOCK TABLES `discapacidades` WRITE;
/*!40000 ALTER TABLE `discapacidades` DISABLE KEYS */;
INSERT INTO `discapacidades` VALUES (1,'Visual'),(2,'Auditiva'),(3,'Motriz');
/*!40000 ALTER TABLE `discapacidades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_admin_log`
--

DROP TABLE IF EXISTS `django_admin_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `django_admin_log` (
  `id` int NOT NULL AUTO_INCREMENT,
  `action_time` datetime(6) NOT NULL,
  `object_id` longtext,
  `object_repr` varchar(200) NOT NULL,
  `action_flag` smallint unsigned NOT NULL,
  `change_message` longtext NOT NULL,
  `content_type_id` int DEFAULT NULL,
  `user_id` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `django_admin_log_content_type_id_c4bce8eb_fk_django_co` (`content_type_id`),
  KEY `django_admin_log_user_id_c564eba6_fk_auth_user_id` (`user_id`),
  CONSTRAINT `django_admin_log_content_type_id_c4bce8eb_fk_django_co` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`),
  CONSTRAINT `django_admin_log_user_id_c564eba6_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`),
  CONSTRAINT `django_admin_log_chk_1` CHECK ((`action_flag` >= 0))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_admin_log`
--

LOCK TABLES `django_admin_log` WRITE;
/*!40000 ALTER TABLE `django_admin_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `django_admin_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_content_type`
--

DROP TABLE IF EXISTS `django_content_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `django_content_type` (
  `id` int NOT NULL AUTO_INCREMENT,
  `app_label` varchar(100) NOT NULL,
  `model` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `django_content_type_app_label_model_76bd3d3b_uniq` (`app_label`,`model`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_content_type`
--

LOCK TABLES `django_content_type` WRITE;
/*!40000 ALTER TABLE `django_content_type` DISABLE KEYS */;
INSERT INTO `django_content_type` VALUES (1,'admin','logentry'),(3,'auth','group'),(2,'auth','permission'),(4,'auth','user'),(5,'contenttypes','contenttype'),(7,'proyecto','ahorros'),(8,'proyecto','beneficiariospersonasnaturales'),(9,'proyecto','creditos'),(10,'proyecto','departamentos'),(11,'proyecto','discapacidades'),(12,'proyecto','estadosciviles'),(13,'proyecto','estudios'),(14,'proyecto','grupos'),(15,'proyecto','municipios'),(16,'proyecto','ocupaciones'),(17,'proyecto','paises'),(18,'proyecto','parentescos'),(27,'proyecto','personasadministrativas'),(26,'proyecto','personasahorroscreditos'),(25,'proyecto','personasbeneficiarios'),(24,'proyecto','personasjefe'),(23,'proyecto','personasnaturales'),(19,'proyecto','porcentajes'),(20,'proyecto','tiposdocumentos'),(21,'proyecto','tiposgeneros'),(22,'proyecto','tiposviviendas'),(6,'sessions','session');
/*!40000 ALTER TABLE `django_content_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_migrations`
--

DROP TABLE IF EXISTS `django_migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `django_migrations` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `app` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `applied` datetime(6) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_migrations`
--

LOCK TABLES `django_migrations` WRITE;
/*!40000 ALTER TABLE `django_migrations` DISABLE KEYS */;
INSERT INTO `django_migrations` VALUES (1,'contenttypes','0001_initial','2023-10-09 20:54:28.260539'),(2,'auth','0001_initial','2023-10-09 20:54:28.785750'),(3,'admin','0001_initial','2023-10-09 20:54:28.890950'),(4,'admin','0002_logentry_remove_auto_add','2023-10-09 20:54:28.901024'),(5,'admin','0003_logentry_add_action_flag_choices','2023-10-09 20:54:28.915131'),(6,'contenttypes','0002_remove_content_type_name','2023-10-09 20:54:28.990704'),(7,'auth','0002_alter_permission_name_max_length','2023-10-09 20:54:29.040688'),(8,'auth','0003_alter_user_email_max_length','2023-10-09 20:54:29.100489'),(9,'auth','0004_alter_user_username_opts','2023-10-09 20:54:29.120569'),(10,'auth','0005_alter_user_last_login_null','2023-10-09 20:54:29.170451'),(11,'auth','0006_require_contenttypes_0002','2023-10-09 20:54:29.170451'),(12,'auth','0007_alter_validators_add_error_messages','2023-10-09 20:54:29.190904'),(13,'auth','0008_alter_user_username_max_length','2023-10-09 20:54:29.252017'),(14,'auth','0009_alter_user_last_name_max_length','2023-10-09 20:54:29.304565'),(15,'auth','0010_alter_group_name_max_length','2023-10-09 20:54:29.360951'),(16,'auth','0011_update_proxy_permissions','2023-10-09 20:54:29.371235'),(17,'auth','0012_alter_user_first_name_max_length','2023-10-09 20:54:29.430863'),(18,'proyecto','0001_initial','2023-10-09 20:54:31.280636'),(19,'sessions','0001_initial','2023-10-09 20:54:31.315165');
/*!40000 ALTER TABLE `django_migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_session`
--

DROP TABLE IF EXISTS `django_session`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `django_session` (
  `session_key` varchar(40) NOT NULL,
  `session_data` longtext NOT NULL,
  `expire_date` datetime(6) NOT NULL,
  PRIMARY KEY (`session_key`),
  KEY `django_session_expire_date_a5c62663` (`expire_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_session`
--

LOCK TABLES `django_session` WRITE;
/*!40000 ALTER TABLE `django_session` DISABLE KEYS */;
INSERT INTO `django_session` VALUES ('zpblrs9oc0a1rur991cys5ammfrfrcr4','.eJxVjDsOwjAQBe_iGlm2k3UsSnrOYO3POIASKU4qxN0hUgpo38y8l8m4rTVvTZc8ijkbb06_GyE_dNqB3HG6zZbnaV1GsrtiD9rsdRZ9Xg7376Biq9869hRClMgC0kEMnri4SEWCY6DCqQwOgbSUpNCnwQ_a7RCRtUNA8_4A_k85Ew:1qqGo8:G-kJts-mn6hdmmbWv4ctrVNQfKC6tl2f0_khsnxR5xE','2023-10-24 17:46:12.630684');
/*!40000 ALTER TABLE `django_session` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `estados_civiles`
--

DROP TABLE IF EXISTS `estados_civiles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `estados_civiles` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `descripcion` varchar(45) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `estados_civiles`
--

LOCK TABLES `estados_civiles` WRITE;
/*!40000 ALTER TABLE `estados_civiles` DISABLE KEYS */;
INSERT INTO `estados_civiles` VALUES (1,'Soltero'),(2,'Casado'),(3,'Divorciado'),(4,'Viudo');
/*!40000 ALTER TABLE `estados_civiles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `estudios`
--

DROP TABLE IF EXISTS `estudios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `estudios` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `descripcion` varchar(45) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `estudios`
--

LOCK TABLES `estudios` WRITE;
/*!40000 ALTER TABLE `estudios` DISABLE KEYS */;
INSERT INTO `estudios` VALUES (1,'Primaria'),(2,'Secundaria'),(3,'Técnico'),(4,'Universitario');
/*!40000 ALTER TABLE `estudios` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `grupos`
--

DROP TABLE IF EXISTS `grupos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `grupos` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `nombre` varchar(45) NOT NULL,
  `persona_admin_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  KEY `grupos_persona_admin_id_8bab3c8b_fk_personas_administrativas_id` (`persona_admin_id`),
  CONSTRAINT `grupos_persona_admin_id_8bab3c8b_fk_personas_administrativas_id` FOREIGN KEY (`persona_admin_id`) REFERENCES `personas_administrativas` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `grupos`
--

LOCK TABLES `grupos` WRITE;
/*!40000 ALTER TABLE `grupos` DISABLE KEYS */;
INSERT INTO `grupos` VALUES (1,'A',1),(2,'B',2),(3,'C',1),(4,'D',1),(5,'E',2),(6,'F',2),(7,'G',3),(8,'H',1),(9,'I',3),(10,'J',1),(11,'K',2);
/*!40000 ALTER TABLE `grupos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `municipios`
--

DROP TABLE IF EXISTS `municipios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `municipios` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `nombre` varchar(45) NOT NULL,
  `departamento_id` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `municipios_departamento_id_93acf47d_fk_departamentos_id` (`departamento_id`),
  CONSTRAINT `municipios_departamento_id_93acf47d_fk_departamentos_id` FOREIGN KEY (`departamento_id`) REFERENCES `departamentos` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `municipios`
--

LOCK TABLES `municipios` WRITE;
/*!40000 ALTER TABLE `municipios` DISABLE KEYS */;
INSERT INTO `municipios` VALUES (1,'Medellín',1),(2,'Barranquilla',2),(3,'Bogotá',3),(4,'Cartagena',4),(5,'Tunja',5);
/*!40000 ALTER TABLE `municipios` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ocupaciones`
--

DROP TABLE IF EXISTS `ocupaciones`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ocupaciones` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `descripcion` varchar(45) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ocupaciones`
--

LOCK TABLES `ocupaciones` WRITE;
/*!40000 ALTER TABLE `ocupaciones` DISABLE KEYS */;
INSERT INTO `ocupaciones` VALUES (1,'Estudiante'),(2,'Empleado'),(3,'Independiente'),(4,'Desempleado');
/*!40000 ALTER TABLE `ocupaciones` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `paises`
--

DROP TABLE IF EXISTS `paises`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `paises` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `nombre` varchar(45) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `paises`
--

LOCK TABLES `paises` WRITE;
/*!40000 ALTER TABLE `paises` DISABLE KEYS */;
INSERT INTO `paises` VALUES (1,'Colombia'),(2,'Estados Unidos'),(3,'Canadá'),(4,'México');
/*!40000 ALTER TABLE `paises` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `parentescos`
--

DROP TABLE IF EXISTS `parentescos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `parentescos` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `descripcion` varchar(45) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `parentescos`
--

LOCK TABLES `parentescos` WRITE;
/*!40000 ALTER TABLE `parentescos` DISABLE KEYS */;
INSERT INTO `parentescos` VALUES (1,'Padre'),(2,'Madre'),(3,'Hijo'),(4,'Hija');
/*!40000 ALTER TABLE `parentescos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `personas_administrativas`
--

DROP TABLE IF EXISTS `personas_administrativas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `personas_administrativas` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `nombres` varchar(80) NOT NULL,
  `apellidos` varchar(80) NOT NULL,
  `fecha_expedicion` date NOT NULL,
  `num_documento` int NOT NULL,
  `fecha_nacimiento` date NOT NULL,
  `correo_electronico` varchar(140) DEFAULT NULL,
  `celular1` varchar(15) NOT NULL,
  `celular2` varchar(15) DEFAULT NULL,
  `discapacidad_id` bigint NOT NULL,
  `genero_id` bigint NOT NULL,
  `jefe_id` bigint NOT NULL,
  `lugar_expedicion_id` bigint NOT NULL,
  `tipo_doc_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  KEY `personas_administrat_discapacidad_id_2542ab69_fk_discapaci` (`discapacidad_id`),
  KEY `personas_administrativas_genero_id_ac3016b8_fk_tipos_generos_id` (`genero_id`),
  KEY `personas_administrativas_jefe_id_901798b2_fk_personas_jefe_id` (`jefe_id`),
  KEY `personas_administrat_lugar_expedicion_id_95996386_fk_municipio` (`lugar_expedicion_id`),
  KEY `personas_administrat_tipo_doc_id_1ec31c29_fk_tipos_doc` (`tipo_doc_id`),
  CONSTRAINT `personas_administrat_discapacidad_id_2542ab69_fk_discapaci` FOREIGN KEY (`discapacidad_id`) REFERENCES `discapacidades` (`id`),
  CONSTRAINT `personas_administrat_lugar_expedicion_id_95996386_fk_municipio` FOREIGN KEY (`lugar_expedicion_id`) REFERENCES `municipios` (`id`),
  CONSTRAINT `personas_administrat_tipo_doc_id_1ec31c29_fk_tipos_doc` FOREIGN KEY (`tipo_doc_id`) REFERENCES `tipos_documentos` (`id`),
  CONSTRAINT `personas_administrativas_genero_id_ac3016b8_fk_tipos_generos_id` FOREIGN KEY (`genero_id`) REFERENCES `tipos_generos` (`id`),
  CONSTRAINT `personas_administrativas_jefe_id_901798b2_fk_personas_jefe_id` FOREIGN KEY (`jefe_id`) REFERENCES `personas_jefe` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `personas_administrativas`
--

LOCK TABLES `personas_administrativas` WRITE;
/*!40000 ALTER TABLE `personas_administrativas` DISABLE KEYS */;
INSERT INTO `personas_administrativas` VALUES (1,'María','López','2022-02-02',987654321,'1995-02-02','maria@example.com','9876543210',NULL,2,2,1,2,2),(2,'pedro','roto','2022-02-02',987654321,'1995-02-02','roto@example.com','9876543210',NULL,2,2,1,2,2),(3,'ocoro','pripra','2023-10-10',3242,'2023-10-10','juan@gmail.com','2323','2323',2,1,1,2,2),(4,'pedro','peponcio','2023-10-10',3242,'2023-10-10','juan@gmail.com','2323','2323',2,1,1,2,2);
/*!40000 ALTER TABLE `personas_administrativas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `personas_ahorros_creditos`
--

DROP TABLE IF EXISTS `personas_ahorros_creditos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `personas_ahorros_creditos` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `fecha` date NOT NULL,
  `ahorro_id` bigint NOT NULL,
  `credito_id` bigint NOT NULL,
  `persona_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  KEY `personas_ahorros_creditos_ahorro_id_8a15b1e5_fk_ahorros_id` (`ahorro_id`),
  KEY `personas_ahorros_creditos_credito_id_3de089f8_fk_creditos_id` (`credito_id`),
  KEY `personas_ahorros_cre_persona_id_05a37179_fk_personas_` (`persona_id`),
  CONSTRAINT `personas_ahorros_cre_persona_id_05a37179_fk_personas_` FOREIGN KEY (`persona_id`) REFERENCES `personas_naturales` (`id`),
  CONSTRAINT `personas_ahorros_creditos_ahorro_id_8a15b1e5_fk_ahorros_id` FOREIGN KEY (`ahorro_id`) REFERENCES `ahorros` (`id`),
  CONSTRAINT `personas_ahorros_creditos_credito_id_3de089f8_fk_creditos_id` FOREIGN KEY (`credito_id`) REFERENCES `creditos` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `personas_ahorros_creditos`
--

LOCK TABLES `personas_ahorros_creditos` WRITE;
/*!40000 ALTER TABLE `personas_ahorros_creditos` DISABLE KEYS */;
INSERT INTO `personas_ahorros_creditos` VALUES (1,'2022-04-04',1,1,1),(2,'2022-04-05',2,2,1);
/*!40000 ALTER TABLE `personas_ahorros_creditos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `personas_beneficiarios`
--

DROP TABLE IF EXISTS `personas_beneficiarios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `personas_beneficiarios` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `beneficiario_id` bigint DEFAULT NULL,
  `persona_natural_id` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `personas_beneficiari_beneficiario_id_b46b5335_fk_beneficia` (`beneficiario_id`),
  KEY `personas_beneficiari_persona_natural_id_689d1cea_fk_personas_` (`persona_natural_id`),
  CONSTRAINT `personas_beneficiari_beneficiario_id_b46b5335_fk_beneficia` FOREIGN KEY (`beneficiario_id`) REFERENCES `beneficiarios_personas_naturales` (`id`),
  CONSTRAINT `personas_beneficiari_persona_natural_id_689d1cea_fk_personas_` FOREIGN KEY (`persona_natural_id`) REFERENCES `personas_naturales` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `personas_beneficiarios`
--

LOCK TABLES `personas_beneficiarios` WRITE;
/*!40000 ALTER TABLE `personas_beneficiarios` DISABLE KEYS */;
INSERT INTO `personas_beneficiarios` VALUES (1,1,1),(2,2,1),(3,3,4),(4,4,4),(5,5,4),(11,23,11),(12,24,11),(13,25,11),(14,26,11),(15,27,12),(16,28,12),(17,29,12),(18,30,12),(19,31,13),(20,32,13),(21,33,13),(22,34,13);
/*!40000 ALTER TABLE `personas_beneficiarios` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `personas_jefe`
--

DROP TABLE IF EXISTS `personas_jefe`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `personas_jefe` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `nombres` varchar(80) NOT NULL,
  `apellidos` varchar(80) NOT NULL,
  `fecha_expedicion` date NOT NULL,
  `num_documento` int NOT NULL,
  `fecha_nacimiento` date NOT NULL,
  `correo_electronico` varchar(140) DEFAULT NULL,
  `celular1` varchar(15) NOT NULL,
  `celular2` varchar(15) DEFAULT NULL,
  `email_computadora` varchar(140) NOT NULL,
  `contrasena_computadora` varchar(45) NOT NULL,
  `discapacidad_id` bigint NOT NULL,
  `genero_id` bigint NOT NULL,
  `lugar_expedicion_id` bigint NOT NULL,
  `tipo_doc_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  KEY `personas_jefe_discapacidad_id_14b0c98a_fk_discapacidades_id` (`discapacidad_id`),
  KEY `personas_jefe_genero_id_93e1e183_fk_tipos_generos_id` (`genero_id`),
  KEY `personas_jefe_lugar_expedicion_id_a10c5299_fk_municipios_id` (`lugar_expedicion_id`),
  KEY `personas_jefe_tipo_doc_id_352b63f9_fk_tipos_documentos_id` (`tipo_doc_id`),
  CONSTRAINT `personas_jefe_discapacidad_id_14b0c98a_fk_discapacidades_id` FOREIGN KEY (`discapacidad_id`) REFERENCES `discapacidades` (`id`),
  CONSTRAINT `personas_jefe_genero_id_93e1e183_fk_tipos_generos_id` FOREIGN KEY (`genero_id`) REFERENCES `tipos_generos` (`id`),
  CONSTRAINT `personas_jefe_lugar_expedicion_id_a10c5299_fk_municipios_id` FOREIGN KEY (`lugar_expedicion_id`) REFERENCES `municipios` (`id`),
  CONSTRAINT `personas_jefe_tipo_doc_id_352b63f9_fk_tipos_documentos_id` FOREIGN KEY (`tipo_doc_id`) REFERENCES `tipos_documentos` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `personas_jefe`
--

LOCK TABLES `personas_jefe` WRITE;
/*!40000 ALTER TABLE `personas_jefe` DISABLE KEYS */;
INSERT INTO `personas_jefe` VALUES (1,'Juan','Perez','2022-01-01',123456789,'1990-01-01','juan@example.com','1234567890',NULL,'juan_computadora@example.com','contraseña1',1,1,1,1);
/*!40000 ALTER TABLE `personas_jefe` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `personas_naturales`
--

DROP TABLE IF EXISTS `personas_naturales`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `personas_naturales` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `nombre_1` varchar(45) NOT NULL,
  `nombre_2` varchar(45) DEFAULT NULL,
  `apellido_1` varchar(45) NOT NULL,
  `apellido_2` varchar(45) DEFAULT NULL,
  `num_documento` int NOT NULL,
  `fecha_expedicion` date NOT NULL,
  `fecha_nacimiento` date NOT NULL,
  `nomenclatura` varchar(45) DEFAULT NULL,
  `barrio_vereda` varchar(45) NOT NULL,
  `correo_electronico` varchar(140) DEFAULT NULL,
  `telefono_fijo` varchar(10) NOT NULL,
  `celular1` varchar(15) NOT NULL,
  `celular2` varchar(15) DEFAULT NULL,
  `deporte_favorito` varchar(45) DEFAULT NULL,
  `edad` int DEFAULT NULL,
  `nombre_completo_recom` varchar(100) DEFAULT NULL,
  `direccion_recom` varchar(45) DEFAULT NULL,
  `celular_recom` varchar(15) DEFAULT NULL,
  `nombre_completo_familiar` varchar(45) DEFAULT NULL,
  `direccion_familiar` varchar(45) DEFAULT NULL,
  `celular_familiar` varchar(15) DEFAULT NULL,
  `email_computadora` varchar(140) NOT NULL,
  `contrasena_computadora` varchar(45) NOT NULL,
  `fecha_regis` varchar(45) NOT NULL,
  `discapacidad_id` bigint NOT NULL,
  `estado_civil_id` bigint NOT NULL,
  `estudios_id` bigint DEFAULT NULL,
  `genero_id` bigint NOT NULL,
  `grupo_id` bigint NOT NULL,
  `lugar_expedicion_id` bigint NOT NULL,
  `lugar_nacimiento_id` bigint NOT NULL,
  `ocupacion_id` bigint NOT NULL,
  `pais_id` bigint NOT NULL,
  `tipo_doc_id` bigint NOT NULL,
  `tipo_vivienda_id` bigint NOT NULL,
  `vive_direccion_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  KEY `personas_naturales_discapacidad_id_7dd56ef9_fk_discapacidades_id` (`discapacidad_id`),
  KEY `personas_naturales_estado_civil_id_6d593987_fk_estados_c` (`estado_civil_id`),
  KEY `personas_naturales_estudios_id_63057f2b_fk_estudios_id` (`estudios_id`),
  KEY `personas_naturales_genero_id_d026784f_fk_tipos_generos_id` (`genero_id`),
  KEY `personas_naturales_grupo_id_efd8707b_fk_grupos_id` (`grupo_id`),
  KEY `personas_naturales_lugar_expedicion_id_1a8b6f43_fk_municipios_id` (`lugar_expedicion_id`),
  KEY `personas_naturales_lugar_nacimiento_id_a1aa2015_fk_municipios_id` (`lugar_nacimiento_id`),
  KEY `personas_naturales_ocupacion_id_edcb69b6_fk_ocupaciones_id` (`ocupacion_id`),
  KEY `personas_naturales_pais_id_8bf10731_fk_paises_id` (`pais_id`),
  KEY `personas_naturales_tipo_doc_id_99792cf8_fk_tipos_documentos_id` (`tipo_doc_id`),
  KEY `personas_naturales_tipo_vivienda_id_cccef356_fk_tipos_viv` (`tipo_vivienda_id`),
  KEY `personas_naturales_vive_direccion_id_18b3602f_fk_municipios_id` (`vive_direccion_id`),
  CONSTRAINT `personas_naturales_discapacidad_id_7dd56ef9_fk_discapacidades_id` FOREIGN KEY (`discapacidad_id`) REFERENCES `discapacidades` (`id`),
  CONSTRAINT `personas_naturales_estado_civil_id_6d593987_fk_estados_c` FOREIGN KEY (`estado_civil_id`) REFERENCES `estados_civiles` (`id`),
  CONSTRAINT `personas_naturales_estudios_id_63057f2b_fk_estudios_id` FOREIGN KEY (`estudios_id`) REFERENCES `estudios` (`id`),
  CONSTRAINT `personas_naturales_genero_id_d026784f_fk_tipos_generos_id` FOREIGN KEY (`genero_id`) REFERENCES `tipos_generos` (`id`),
  CONSTRAINT `personas_naturales_grupo_id_efd8707b_fk_grupos_id` FOREIGN KEY (`grupo_id`) REFERENCES `grupos` (`id`),
  CONSTRAINT `personas_naturales_lugar_expedicion_id_1a8b6f43_fk_municipios_id` FOREIGN KEY (`lugar_expedicion_id`) REFERENCES `municipios` (`id`),
  CONSTRAINT `personas_naturales_lugar_nacimiento_id_a1aa2015_fk_municipios_id` FOREIGN KEY (`lugar_nacimiento_id`) REFERENCES `municipios` (`id`),
  CONSTRAINT `personas_naturales_ocupacion_id_edcb69b6_fk_ocupaciones_id` FOREIGN KEY (`ocupacion_id`) REFERENCES `ocupaciones` (`id`),
  CONSTRAINT `personas_naturales_pais_id_8bf10731_fk_paises_id` FOREIGN KEY (`pais_id`) REFERENCES `paises` (`id`),
  CONSTRAINT `personas_naturales_tipo_doc_id_99792cf8_fk_tipos_documentos_id` FOREIGN KEY (`tipo_doc_id`) REFERENCES `tipos_documentos` (`id`),
  CONSTRAINT `personas_naturales_tipo_vivienda_id_cccef356_fk_tipos_viv` FOREIGN KEY (`tipo_vivienda_id`) REFERENCES `tipos_viviendas` (`id`),
  CONSTRAINT `personas_naturales_vive_direccion_id_18b3602f_fk_municipios_id` FOREIGN KEY (`vive_direccion_id`) REFERENCES `municipios` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `personas_naturales`
--

LOCK TABLES `personas_naturales` WRITE;
/*!40000 ALTER TABLE `personas_naturales` DISABLE KEYS */;
INSERT INTO `personas_naturales` VALUES (1,'Carlos',NULL,'Gomez',NULL,234567890,'2022-03-03','1991-03-03',NULL,'Barrio A','carlos@example.com','1','2345678901',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'carlos_computadora@example.com','contraseña2','2022-03-03',1,2,3,1,1,3,1,1,1,1,1,1),(2,'juan','peponcio','ppee','dengue',3242,'2023-10-09','2023-10-09','xdcf','efwf','jhonier@gmail.com','323','3234939330',NULL,'stun',34,'aafaf','afafa','22323','culito','adas','3233','','','10/2023',1,1,2,1,1,3,1,2,1,2,1,3),(3,'natalia','jacinta','merengue','dengue',3242,'2023-10-09','2023-10-09','juan','xd','jhonier@gmail.com','323','3234939330',NULL,'stun',89,'aafaf','afafa','22323','afafa','adas','3233','','','10/2023',2,1,3,1,1,3,1,3,1,2,1,2),(4,'kokokok','peponcio','ppee','wewe',3242,'2023-10-09','2023-10-09','juan','efwf','jhonier@gmail.com','323','3234939330',NULL,'stun',78,'aafaf','afafa','22323','culito','adas','3233','','','10/2023',1,1,3,1,2,3,1,2,1,3,1,2),(5,'culon','ewe','ppee','dengue',3242,'2023-10-09','2023-10-09','juan','efwf','jhonier@gmail.com','323','3234939330',NULL,'stun',89,'aafaf','afafa','22323','culito','adas','3233','','','10/2023',1,1,2,1,1,1,1,2,1,2,1,5),(6,'gttttttttt','ewe','ppee','dengue',3242,'2023-10-09','2023-10-09','juan','efwf','jhonier@gmail.com','323','3234939330',NULL,'stun',89,'aafaf','afafa','22323','culito','adas','3233','','','10/2023',1,1,2,1,2,1,1,2,1,2,1,5),(7,'jh','peponcio','merengue','dengue',3242,'2023-10-09','2023-10-09','xdcf','efwf','jhonier@gmail.com','323','131313',NULL,'stun',23,'aafaf','afafa','22323','afafa','adas','3233','','','10/2023',1,2,4,1,1,3,2,2,1,1,1,2),(8,'jh','peponcio','merengue','dengue',3242,'2023-10-09','2023-10-09','xdcf','efwf','jhonier@gmail.com','323','131313',NULL,'stun',23,'aafaf','afafa','22323','afafa','adas','3233','','','10/2023',1,2,4,1,1,3,2,2,1,1,1,2),(9,'juan','peponcio','ppee','dengue',3242,'2023-10-10','2023-10-10','juan','efwf','jhonier@gmail.com','323','3234939330',NULL,'stun',23,'aafaf','afafa','22323','afafa','adas','3233','','','10/2023',1,1,2,2,2,3,4,2,1,2,3,5),(10,'julio','segundo','ortencio','castro',123313,'2023-10-10','2023-10-10','juan','xd','jhonier@gmail.com','323','3234939330',NULL,'stun',20,'aafaf','afafa','22323','culito','adas','3233','','','10/2023',1,2,1,2,1,3,2,1,3,1,1,5),(11,'sierra','peponcio','merengue','dd',123313,'2023-10-10','2023-10-10','juan','xd','jhonier@gmail.com','323','3234939330',NULL,'stun',34,'aafaf','afafa','22323','afafa','adas','3233','','','10/2023',2,1,1,2,1,3,1,1,1,1,1,2),(12,'juan','','merengue','wewe',3242,'2023-10-10','2023-10-10','xdcf','efwf','jhonier@gmail.com','323','3234939330',NULL,'stun',23,'aafaf','afafa','22323','afafa','adas','3233','','','10/2023',1,1,1,1,1,3,2,2,1,1,2,2),(13,'culon','','ppee','dengue',3242,'2023-10-10','2023-10-10','juan','efwf','jhonier@gmail.com','0','131313',NULL,'stun',34,'aafaf','afafa','22323','afafa','adas','3233','','','10/2023',1,2,3,1,1,3,2,2,2,1,2,1);
/*!40000 ALTER TABLE `personas_naturales` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `porcentajes`
--

DROP TABLE IF EXISTS `porcentajes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `porcentajes` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `descripcion` varchar(45) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `porcentajes`
--

LOCK TABLES `porcentajes` WRITE;
/*!40000 ALTER TABLE `porcentajes` DISABLE KEYS */;
INSERT INTO `porcentajes` VALUES (1,'10%'),(2,'20%'),(3,'30%'),(4,'40%');
/*!40000 ALTER TABLE `porcentajes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tipos_documentos`
--

DROP TABLE IF EXISTS `tipos_documentos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tipos_documentos` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `descripcion` varchar(45) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tipos_documentos`
--

LOCK TABLES `tipos_documentos` WRITE;
/*!40000 ALTER TABLE `tipos_documentos` DISABLE KEYS */;
INSERT INTO `tipos_documentos` VALUES (1,'Cédula de Ciudadanía'),(2,'Tarjeta de Identidad'),(3,'Cédula de Extranjería'),(4,'Pasaporte');
/*!40000 ALTER TABLE `tipos_documentos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tipos_generos`
--

DROP TABLE IF EXISTS `tipos_generos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tipos_generos` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `descripcion` varchar(45) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tipos_generos`
--

LOCK TABLES `tipos_generos` WRITE;
/*!40000 ALTER TABLE `tipos_generos` DISABLE KEYS */;
INSERT INTO `tipos_generos` VALUES (1,'Masculino'),(2,'Femenino'),(3,'Otro');
/*!40000 ALTER TABLE `tipos_generos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tipos_viviendas`
--

DROP TABLE IF EXISTS `tipos_viviendas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tipos_viviendas` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `descripcion` varchar(45) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tipos_viviendas`
--

LOCK TABLES `tipos_viviendas` WRITE;
/*!40000 ALTER TABLE `tipos_viviendas` DISABLE KEYS */;
INSERT INTO `tipos_viviendas` VALUES (1,'Casa'),(2,'Apartamento'),(3,'Finca');
/*!40000 ALTER TABLE `tipos_viviendas` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-10-10 13:45:47
